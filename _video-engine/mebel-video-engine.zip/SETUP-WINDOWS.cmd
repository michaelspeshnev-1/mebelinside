@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist package.json (echo Запустите файл из папки проекта, где лежит package.json & pause & exit /b 1)
powershell -NoProfile -ExecutionPolicy Bypass -File scripts\setup.ps1
pause
